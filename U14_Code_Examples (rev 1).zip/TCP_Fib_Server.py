from socket import *

def fib(n):
    if n == 0: return 0
    elif n == 1: return 1
    else: return fib(n-1)+fib(n-2)

def handle_request(client):
    buf = ""
    while True:
        d = client.recv(1)
        if d == "\n" or d == "\0":
            break
        buf += d
    number = int(buf)

    fibNumber = fib(number)
    client.send(str(fibNumber))
    client.close()

def main():
    s = socket(AF_INET, SOCK_STREAM)
    s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", 9000))
    s.listen(1)
    client_socket, peer = s.accept()
    handle_request(client_socket)
    s.close()

if __name__ == "__main__":
    main()
