from socket import *
import datetime

s = socket(AF_INET, SOCK_DGRAM)
s.bind(("0.0.0.0", 9000))

try:
    while True:
        req, sender = s.recvfrom(1000)
        print "Sender", sender, "asked for:", req
        now = datetime.datetime.now()
        print "Replying with:", now
        s.sendto(now.isoformat(), sender)
except KeyboardInterrupt:
    pass
finally:
    s.close()
