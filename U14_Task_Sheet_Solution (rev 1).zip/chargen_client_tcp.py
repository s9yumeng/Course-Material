from socket import *

s = socket(AF_INET, SOCK_STREAM)
s.connect(("localhost", 8000))
res, _ = s.recvfrom(1024)
print(res.decode())
s.close()
