from socket import *

s = socket(AF_INET, SOCK_DGRAM)
data = bytes()   # this could be anything
s.sendto(data, ("localhost", 19))
res, addr = s.recvfrom(1024)
print(res.decode())
