from socket import *

s = socket(AF_INET, SOCK_DGRAM)
cmd = "time"
sent = s.sendto(cmd, ('127.0.0.1', 9000))
print "Requested", cmd, "which is", sent, "bytes long."
time, sender = s.recvfrom(100)
print "Sender", sender, "replied with time:", time
s.close()
