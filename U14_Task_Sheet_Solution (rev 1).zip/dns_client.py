from socket import *
from struct import *

name = "uni-saarland.de"

s = socket(AF_INET, SOCK_DGRAM)

ident = 47
flags = 0
quest_no = 1
answer_no = 0
auth_no = 0
add_no = 0

data = pack("!HHHHHH", ident, flags, quest_no, answer_no, auth_no, add_no)

question = bytes()
labels = name.split(".")
for label in labels:
    question += bytes(chr(len(label)) + label, "ascii")
question += pack("!BHH", 0x0, 0x0001, 0x0001)

data += question

s.sendto(data, ("134.96.252.20", 53))
resp, addr = s.recvfrom(4092)
print(inet_ntoa(resp[45:49]))
