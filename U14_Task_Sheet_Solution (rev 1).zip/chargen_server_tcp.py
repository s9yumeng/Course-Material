from socket import *
import signal
import os

def handle_request(client_socket):
    while True:
        try:
            print("SEND")
            client_socket.sendall("1234567890".encode())
        except:
            break
    print("CLOSING")
    client_socket.close()

def main():
    s = socket(AF_INET, SOCK_STREAM)
    s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
    s.bind(("localhost", 8000))
    s.listen(5)
    signal.signal(signal.SIGCHLD, signal.SIG_IGN)
    try:
        while True:
            client_socket, peer = s.accept()
            child_pid = os.fork()
            if child_pid == 0:
                handle_request(client_socket)
                break
            else:
                client_socket.close()
    except KeyboardInterrupt:
        pass
    finally:
        s.close()

if __name__ == "__main__":
    main()
