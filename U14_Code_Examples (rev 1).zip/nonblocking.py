import socket
import errno
import time

s = socket.socket(socket.AF_INET,
                  socket.SOCK_STREAM,
                  0)

print "connecting!"
s.connect(("smtp.uni-saarland.de", 25))
print "connected!"
s.setblocking(0)

while True:
    try:
        print "received: %s" % s.recv(1024)
        break
    except socket.error as e:
        err = e.args[0]
        if err == errno.EAGAIN:
            print "EAGAIN"
        if err == errno.EWOULDBLOCK:
            print "EWOULDBLOCK"
        time.sleep(0.01)    # avoid busy loop
