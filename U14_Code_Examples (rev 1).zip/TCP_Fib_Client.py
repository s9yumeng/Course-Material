from socket import *
import datetime

start = datetime.datetime.now()
n = 37
s = socket(AF_INET, SOCK_STREAM)
s.connect(("localhost", 9000))
s.send("%d\n" % (n))
r = int(s.recv(10))
stop = datetime.datetime.now()
d = (stop - start).total_seconds()
print "fib(%d)=%d (%fs calc time)" % (n,r,d)
s.close()
